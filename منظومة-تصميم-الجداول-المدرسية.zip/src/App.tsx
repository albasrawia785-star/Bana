import React, { useState, useEffect } from "react";
import { 
  School, 
  Calendar, 
  BookOpen, 
  PlusCircle, 
  Trash2, 
  UserCheck, 
  Printer, 
  Settings, 
  Clock, 
  Sparkles, 
  Send,
  AlertCircle,
  FileText,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  Plus,
  CheckCircle2,
  X,
  Info,
  Download
} from "lucide-react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

interface Stage {
  name: string;
  subjects: string[];
}

const INITIAL_STAGES_CONFIG: Record<string, Stage> = {
  "1": { name: "الأول الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم"] },
  "2": { name: "الثاني الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم"] },
  "3": { name: "الثالث الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم"] },
  "4": { name: "الرابع الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم", "الاجتماعيات"] },
  "5": { name: "الخامس الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم", "الاجتماعيات"] },
  "6": { name: "السادس الابتدائي", subjects: ["التربية الإسلامية", "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم", "الاجتماعيات"] }
};

export default function App() {
  // --- States ---
  const [stagesConfig, setStagesConfig] = useState<Record<string, Stage>>(INITIAL_STAGES_CONFIG);
  
  // School details
  const [schoolName, setSchoolName] = useState<string>("");
  
  // Dynamic Academic Years list
  const [academicYears, setAcademicYears] = useState<string[]>([]);
  const [selectedAcademicYear, setSelectedAcademicYear] = useState<string>("");
  
  // Schedule settings
  const [examType, setExamType] = useState<string>("الامتحانات الشهرية");
  const [tableMode, setTableMode] = useState<"all" | "single">("all");
  
  // Entry insertion states
  const [rowDate, setRowDate] = useState<string>("");
  const [selectedStage, setSelectedStage] = useState<string>("6"); // Default to 6th stage for quick entry
  const [selectedSubject, setSelectedSubject] = useState<string>("");
  const [examTime, setExamTime] = useState<string>("الساعة 08:00 صباحاً");
  
  // Custom subject inputs
  const [customSubjectText, setCustomSubjectText] = useState<string>("");
  const [managerName, setManagerName] = useState<string>("");
  
  // Table Data State: { "YYYY-MM-DD": { "stage_id": "subject_name" } }
  const [examData, setExamData] = useState<Record<string, Record<string, string>>>({});

  // Navigation state (Android Mobile layout: Control Panel tab vs Preview tab)
  const [activeTab, setActiveTab] = useState<"control" | "preview">("control");

  // Custom alert/snackbar state
  const [snackbar, setSnackbar] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // Custom confirm dialog state
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Help/Print fallback Modal
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  // Initialize academic years list
  useEffect(() => {
    const currentYear = new Date().getFullYear();
    const list: string[] = [];
    for (let i = 0; i < 5; i++) {
      const start = currentYear + i - 1;
      const end = start + 1;
      list.push(`${start} - ${end}`);
    }
    setAcademicYears(list);
    if (list.length > 1) {
      setSelectedAcademicYear(list[1]);
    } else {
      setSelectedAcademicYear(`${currentYear} - ${currentYear + 1}`);
    }

    // Default row date to today
    const today = new Date().toISOString().split("T")[0];
    setRowDate(today);
  }, []);

  // Update default selected subject on stage changes
  useEffect(() => {
    if (stagesConfig[selectedStage]?.subjects?.length > 0) {
      setSelectedSubject(stagesConfig[selectedStage].subjects[0]);
    } else {
      setSelectedSubject("");
    }
  }, [selectedStage, stagesConfig]);

  // Snackbar triggers
  const triggerSnackbar = (message: string, type: "success" | "error" | "info" = "success") => {
    setSnackbar({ message, type });
  };

  // Auto-hide snackbar
  useEffect(() => {
    if (snackbar) {
      const timer = setTimeout(() => {
        setSnackbar(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [snackbar]);

  // Check if Exam Type is Monthly
  const isMonthly = examType.includes("شهر") || examType === "الامتحانات الشهرية";

  // --- Actions ---
  
  // State for tracking PDF rendering progress to prevent double clicks and show loading state
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  // Handle Exporting PDF with html2canvas and jsPDF for an incredibly clean offline download
  const handleExportPDF = () => {
    const element = document.getElementById("print-area");
    if (!element) {
      triggerSnackbar("خطأ: لم يتم العثور على منطقة الطباعة.", "error");
      return;
    }

    setIsExportingPdf(true);
    triggerSnackbar("جاري معالجة وتجهيز ملف PDF... يرجى الانتظار لحين تحميل الملف تلقائياً.", "info");

    // Use a brief timeout to let the loader render on screen
    setTimeout(() => {
      html2canvas(element, {
        scale: 2, // High clarity scale
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
        scrollX: 0,
        scrollY: 0,
        ignoreElements: (el) => el.classList.contains("no-print")
      }).then((canvas) => {
        try {
          const imgData = canvas.toDataURL("image/jpeg", 0.95);
          
          const isLandscape = tableMode === "all";
          const orientation = (isLandscape ? "landscape" : "portrait") as "landscape" | "portrait";
          
          const pdf = new jsPDF({
            orientation: orientation,
            unit: "px",
            format: "a4"
          });

          // A4 page dimensions in px inside jsPDF
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = pdf.internal.pageSize.getHeight();
          
          const canvasWidth = canvas.width;
          const canvasHeight = canvas.height;
          
          // Fit into one full A4 page perfectly with margins
          const margin = 20; // margins in pixels
          const maxPdfWidth = pdfWidth - margin * 2;
          const maxPdfHeight = pdfHeight - margin * 2;
          
          const ratio = Math.min(maxPdfWidth / canvasWidth, maxPdfHeight / canvasHeight);
          
          const imgWidth = canvasWidth * ratio;
          const imgHeight = canvasHeight * ratio;
          
          const xOffset = (pdfWidth - imgWidth) / 2;
          const yOffset = (pdfHeight - imgHeight) / 2;

          pdf.addImage(imgData, "JPEG", xOffset, yOffset, imgWidth, imgHeight);
          
          const cleanSchoolName = schoolName ? schoolName.trim() : "المرحلة_الابتدائية";
          const cleanExamType = examType ? examType.trim() : "جدول_الامتحانات";
          const fileName = `${cleanExamType}_${cleanSchoolName}.pdf`.replace(/\s+/g, "_");

          pdf.save(fileName);
          triggerSnackbar("تم تصدير وتحميل ملف PDF بنجاح! 🎉", "success");
        } catch (error) {
          console.error("Failed to generate PDF:", error);
          triggerSnackbar("حدث خطأ أثناء تصدير ملف PDF. يرجى المحاولة مرة أخرى.", "error");
        } finally {
          setIsExportingPdf(false);
        }
      }).catch((err) => {
        console.error("html2canvas error:", err);
        triggerSnackbar("حدث خطأ أثناء التقاط الجدول. يرجى المحاولة مرة أخرى.", "error");
        setIsExportingPdf(false);
      });
    }, 300);
  };

  // Handle Printing safely with direct native print dialog which enables direct high fidelity PDF export
  const handlePrint = () => {
    const element = document.getElementById("print-area");
    if (!element) {
      triggerSnackbar("خطأ: لم يتم العثور على منطقة الطباعة.", "error");
      return;
    }

    triggerSnackbar("جاري فتح نافذة الطباعة... اختر 'حفظ كملف PDF' أو اسم طابعتك لحفظ أو طباعة الجدول بجودة عالية.", "info");

    // We do a brief timeout to allow the snackbar state to render, then trigger print
    setTimeout(() => {
      try {
        window.focus();
        window.print();
      } catch (e) {
        console.error("Browser print failed", e);
        triggerSnackbar("فشلت عملية الطباعة المباشرة. يرجى محاولة استخدام الطباعة من متصفحك مباشرة.", "error");
      }
    }, 400);
  };
  
  // Insert or Update table data
  const handleInsertSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rowDate) {
      triggerSnackbar("يرجى تحديد تاريخ الامتحان أولاً.", "error");
      return;
    }

    setExamData(prev => {
      const dateRecord = prev[rowDate] || {};
      return {
        ...prev,
        [rowDate]: {
          ...dateRecord,
          [selectedStage]: selectedSubject === "" ? "——" : selectedSubject
        }
      };
    });

    triggerSnackbar(`تم تثبيت المادة لـ (${stagesConfig[selectedStage]?.name}) في الجدول.`, "success");
  };

  // Add custom subject to the selected stage
  const handleAddCustomSubject = () => {
    const subject = customSubjectText.trim();
    if (!subject) return;

    if (stagesConfig[selectedStage]) {
      const currentSubjects = stagesConfig[selectedStage].subjects;
      if (currentSubjects.includes(subject)) {
        triggerSnackbar("هذه المادة مضافة بالفعل لهذا الصف.", "error");
        return;
      }

      setStagesConfig(prev => ({
        ...prev,
        [selectedStage]: {
          ...prev[selectedStage],
          subjects: [...prev[selectedStage].subjects, subject]
        }
      }));

      triggerSnackbar(`تمت إضافة مادة "${subject}" بنجاح إلى مواد (${stagesConfig[selectedStage].name}).`, "success");
      setSelectedSubject(subject);
      setCustomSubjectText("");
    }
  };

  // Clear specific cell in the table
  const handleClearCell = (dateStr: string, stageId: string) => {
    setExamData(prev => {
      const dateRecord = { ...prev[dateStr] };
      delete dateRecord[stageId];
      
      const newExamData = { ...prev };
      if (Object.keys(dateRecord).length === 0) {
        delete newExamData[dateStr];
      } else {
        newExamData[dateStr] = dateRecord;
      }
      return newExamData;
    });
    triggerSnackbar("تم حذف المادة المحددة من الخلية.", "info");
  };

  // Delete a complete row (date) from the table
  const handleDeleteRow = (dateStr: string) => {
    setConfirmDialog({
      isOpen: true,
      title: "تأكيد حذف يوم ⚠️",
      message: `هل أنت متأكد من حذف هذا اليوم (${dateStr}) بالكامل من الجدول بما يحتويه من امتحانات؟`,
      onConfirm: () => {
        setExamData(prev => {
          const copy = { ...prev };
          delete copy[dateStr];
          return copy;
        });
        triggerSnackbar("تم حذف اليوم المحدد بالكامل.", "success");
        setConfirmDialog(null);
      }
    });
  };

  // Clear the whole schedule (Fixes the blocked confirm hanging bug)
  const handleClearTable = () => {
    setConfirmDialog({
      isOpen: true,
      title: "مسح الجدول بالكامل 🗑️",
      message: "هل أنت متأكد من رغبتك في مسح كافة بيانات الجدول الحالية؟ هذه العملية لا يمكن التراجع عنها مطلقاً.",
      onConfirm: () => {
        setExamData({});
        triggerSnackbar("تم مسح كافة بيانات الجدول الحالية بنجاح.", "success");
        setConfirmDialog(null);
      }
    });
  };

  // Fill Sample Data for beautiful preview
  const handleLoadSampleData = () => {
    const today = new Date();
    const daysOffset = [0, 1, 2, 3, 4, 5];
    const newExamData: Record<string, Record<string, string>> = {};

    daysOffset.forEach((offset, idx) => {
      const d = new Date();
      d.setDate(today.getDate() + offset);
      const dateString = d.toISOString().split("T")[0];
      
      newExamData[dateString] = {
        "1": INITIAL_STAGES_CONFIG["1"].subjects[idx % INITIAL_STAGES_CONFIG["1"].subjects.length],
        "2": INITIAL_STAGES_CONFIG["2"].subjects[(idx + 1) % INITIAL_STAGES_CONFIG["2"].subjects.length],
        "3": INITIAL_STAGES_CONFIG["3"].subjects[(idx + 2) % INITIAL_STAGES_CONFIG["3"].subjects.length],
        "4": INITIAL_STAGES_CONFIG["4"].subjects[(idx + 3) % INITIAL_STAGES_CONFIG["4"].subjects.length],
        "5": INITIAL_STAGES_CONFIG["5"].subjects[(idx + 4) % INITIAL_STAGES_CONFIG["5"].subjects.length],
        "6": INITIAL_STAGES_CONFIG["6"].subjects[(idx + 5) % INITIAL_STAGES_CONFIG["6"].subjects.length],
      };
    });

    setSchoolName("مدرسة الرافدين الابتدائية");
    setManagerName("الأستاذ أحمد السامرائي");
    setExamType("الامتحانات النهائية");
    setExamData(newExamData);
    triggerSnackbar("تم ملء الجدول بالبيانات النموذجية الافتراضية للوزارة! ✨", "success");
  };

  // Calculate dynamic header title
  const dynamicTitle = tableMode === "all"
    ? `جدول ${examType} الموحد`
    : `جدول ${examType} - صف ${stagesConfig[selectedStage]?.name || ""}`;

  // Process and sort exam dates
  const sortedDates = Object.keys(examData).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

  // Helper to format date in Arabic locale without offset issues
  const formatArabicDate = (dateStr: string) => {
    try {
      const parts = dateStr.split("-");
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      
      const dateObj = new Date(year, month, day);
      
      const dayName = new Intl.DateTimeFormat("ar-EG", { weekday: "long" }).format(dateObj);
      const dateDisplay = `${year}/${month + 1}/${day}`;
      
      return { dayName, dateDisplay };
    } catch (e) {
      return { dayName: "—", dateDisplay: dateStr };
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900 font-sans pb-16 selection:bg-blue-100">
      
      {/* Premium Android App Bar */}
      <div className="no-print sticky top-0 z-40 bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white shadow-md border-b border-blue-700/50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/10 p-2 rounded-xl border border-white/20 shadow-inner">
              <Smartphone className="w-6 h-6 text-blue-200" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[10px] uppercase font-bold text-blue-200 tracking-wider">منصة التعليم الابتدائي الذكية</span>
              </div>
              <h1 className="text-base font-extrabold tracking-tight">مُصمم الجداول المدرسية</h1>
            </div>
          </div>

          {/* Quick Stats Badge */}
          <div className="hidden md:flex items-center gap-2 bg-black/25 px-3 py-1.5 rounded-full border border-white/10 text-xs text-blue-100 font-bold">
            <Calendar className="w-4 h-4 text-blue-300" />
            <span>الأيام المدرجة: {sortedDates.length}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleLoadSampleData}
              className="px-3 py-1.5 text-xs bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 font-bold rounded-lg transition duration-150 flex items-center gap-1 shadow"
            >
              <Sparkles className="w-3.5 h-3.5" />
              نموذج جاهز ✨
            </button>
          </div>
        </div>

        {/* Beautiful Android Segmented Control Tab Bar */}
        <div className="max-w-7xl mx-auto px-4 border-t border-white/10 bg-blue-950/45 flex justify-around">
          <button
            onClick={() => setActiveTab("control")}
            className={`flex-1 py-3 text-center text-xs font-black tracking-wide border-b-2 transition duration-200 flex items-center justify-center gap-2 ${
              activeTab === "control" 
                ? "border-blue-300 text-blue-100 bg-white/5" 
                : "border-transparent text-blue-300 hover:text-white"
            }`}
          >
            <Settings className="w-4 h-4" />
            تعديل وإعداد البيانات (لوحة التحكم)
          </button>
          <button
            onClick={() => setActiveTab("preview")}
            className={`flex-1 py-3 text-center text-xs font-black tracking-wide border-b-2 transition duration-200 flex items-center justify-center gap-2 ${
              activeTab === "preview" 
                ? "border-blue-300 text-blue-100 bg-white/5" 
                : "border-transparent text-blue-300 hover:text-white"
            }`}
          >
            <FileText className="w-4 h-4" />
            معاينة وطباعة جدول الامتحانات الرسمية
          </button>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-6">
        
        {/* TAB 1: CONTROL PANEL */}
        {activeTab === "control" && (
          <div className="no-print space-y-6">
            
            {/* Info Hint */}
            <div className="bg-blue-50 border-r-4 border-blue-600 p-4 rounded-xl flex items-start gap-3 shadow-xs">
              <Info className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
              <div className="text-xs text-blue-950 leading-relaxed space-y-1">
                <p className="font-extrabold">مرحباً بك في منظومة الجدولة العراقية الذكية! 🇮🇶</p>
                <p>يمكنك تعديل المواد والتواريخ من هنا وسيقوم النظام بتحديث الجدول تلقائياً. عند الانتهاء، تفضل بالانتقال إلى علامة تبويب <strong>"معاينة وطباعة جدول الامتحانات الرسمية"</strong> لتصدير الجدول بجودة A4 فائقة الدقة.</p>
              </div>
            </div>

            {/* Grid of panels */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Panel: Primary Configs */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* School Profile and Settings */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-3 h-3 rounded-full bg-blue-600"></div>
                    <h3 className="text-xs font-black text-slate-800">بيانات المدرسة العامة</h3>
                  </div>

                  <div className="space-y-4">
                    {/* School Name Input */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500 uppercase">اسم المدرسة</label>
                      <input
                        type="text"
                        value={schoolName}
                        onChange={(e) => setSchoolName(e.target.value)}
                        placeholder="مثال: مدرسة الرافدين الابتدائية"
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    {/* Academic Year Selection */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500 uppercase">العام الدراسي</label>
                      <select
                        value={selectedAcademicYear}
                        onChange={(e) => setSelectedAcademicYear(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                      >
                        {academicYears.map((yr) => (
                          <option key={yr} value={yr}>{yr}</option>
                        ))}
                      </select>
                    </div>

                    {/* Exam Type Selection */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500 uppercase">نوع وموسم الامتحان</label>
                      <select
                        value={examType}
                        onChange={(e) => setExamType(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                      >
                        <option value="الامتحانات الشهرية">امتحانات شهرية (عام)</option>
                        <option value="امتحان الشهر الأول">امتحان الشهر الأول</option>
                        <option value="امتحان الشهر الثاني">امتحان الشهر الثاني</option>
                        <option value="امتحانات نصف السنة">امتحان نصف السنة</option>
                        <option value="الامتحانات النهائية">الامتحانات النهائية</option>
                      </select>
                    </div>

                    {/* Table View Mode Selection */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500 uppercase">نظام عرض وتصميم الجدول</label>
                      <select
                        value={tableMode}
                        onChange={(e) => setTableMode(e.target.value as "all" | "single")}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                      >
                        <option value="all">جدول مركزي شامل (لكل صفوف المرحلة من الأول للسادس)</option>
                        <option value="single">جدول منفصل ومخصص (لصف واحد يتم تحديده)</option>
                      </select>
                    </div>

                    {/* Conditional exam start hour */}
                    {!isMonthly && (
                      <div className="space-y-1 animate-fade-in">
                        <label className="text-[11px] font-bold text-slate-500 uppercase">ساعة بدء الامتحان</label>
                        <input
                          type="text"
                          value={examTime}
                          onChange={(e) => setExamTime(e.target.value)}
                          placeholder="الساعة 08:00 صباحاً"
                          className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:border-blue-500 focus:outline-none"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Director Profile */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-3 h-3 rounded-full bg-indigo-600"></div>
                    <h3 className="text-xs font-black text-slate-800">بيانات التوقيع والاعتماد</h3>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-500">اسم مدير المدرسة الكامل</label>
                      <input
                        type="text"
                        value={managerName}
                        onChange={(e) => setManagerName(e.target.value)}
                        placeholder="مثال: الأستاذ علي أحمد الخفاجي"
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

              </div>

              {/* Right Panel: Exam Entries Insertion */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Inset New Subject Table Form */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-teal-600"></div>
                      <h3 className="text-xs font-black text-slate-800">إدراج وتحديث المواد في الجدول</h3>
                    </div>
                    <span className="text-[10px] bg-teal-50 text-teal-700 font-bold px-2 py-0.5 rounded-full">إدخال ذكي</span>
                  </div>

                  <form onSubmit={handleInsertSubject} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Date selection */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-600">1. تاريخ الامتحان</label>
                        <input
                          type="date"
                          required
                          value={rowDate}
                          onChange={(e) => setRowDate(e.target.value)}
                          className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                        />
                      </div>

                      {/* Stage selection */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-600">2. الصف المعني</label>
                        <select
                          value={selectedStage}
                          onChange={(e) => setSelectedStage(e.target.value)}
                          className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                        >
                          {Object.keys(stagesConfig).map((key) => (
                            <option key={key} value={key}>
                              {stagesConfig[key].name}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Subject selection */}
                      <div className="space-y-1 sm:col-span-2">
                        <label className="text-[11px] font-bold text-slate-600">3. اسم المادة الدراسية</label>
                        <select
                          value={selectedSubject}
                          onChange={(e) => setSelectedSubject(e.target.value)}
                          className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                        >
                          <option value="">— عطلة رسمية / لا يوجد امتحان —</option>
                          {stagesConfig[selectedStage]?.subjects.map((sub, i) => (
                            <option key={i} value={sub}>{sub}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md transition duration-150 flex items-center justify-center gap-1.5"
                    >
                      <PlusCircle className="w-4 h-4" />
                      تثبيت المادة في الجدول المقابل ↩
                    </button>
                  </form>
                </div>

                {/* Add Custom/New Subject */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                      <h3 className="text-xs font-black text-slate-800">إضافة مادة مخصصة غير افتراضية للوزارة</h3>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-[10.5px] text-slate-500 leading-normal">
                      يمكنك هنا إضافة أي مادة دراسية اختيارية جديدة غير مدرجة تلقائياً لتظهر في خيارات صف <strong className="text-blue-900">({stagesConfig[selectedStage]?.name})</strong>:
                    </p>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={customSubjectText}
                        onChange={(e) => setCustomSubjectText(e.target.value)}
                        placeholder="مثال: التربية الفنية، المهارات الحياتية..."
                        className="flex-1 text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold focus:bg-white focus:outline-none"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleAddCustomSubject();
                        }}
                      />
                      <button
                        onClick={handleAddCustomSubject}
                        className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition whitespace-nowrap active:scale-95"
                      >
                        إضافة للصف المختار
                      </button>
                    </div>
                  </div>
                </div>

                {/* Danger Operations Card */}
                <div className="bg-red-50/50 border border-red-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="space-y-1 text-center sm:text-right">
                    <h4 className="text-xs font-black text-red-950">تصفير وإعادة تعيين البيانات</h4>
                    <p className="text-[10px] text-red-700 leading-normal">سيتم حذف كافة الأيام والمواد التي قمت بتعبئتها حتى الآن والعودة لجدول فارغ.</p>
                  </div>
                  <button
                    onClick={handleClearTable}
                    className="w-full sm:w-auto px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow active:scale-95 transition duration-150 flex items-center justify-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" />
                    مسح الجدول كامل 🗑️
                  </button>
                </div>

              </div>

            </div>

            {/* Micro Live Preview of Table at control panel bottom */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-xs font-black text-slate-800 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-500" />
                  معاينة سريعة لجدول الإدخال الحالي
                </h3>
                <span className="text-[10px] text-slate-400">تحديث فوري</span>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full border-collapse text-[11px] sm:text-[12px] text-slate-900">
                  <thead>
                    <tr className="bg-slate-100">
                      <th className="border border-slate-200 p-2 text-center w-20">اليوم</th>
                      <th className="border border-slate-200 p-2 text-center w-24">التاريخ</th>
                      {tableMode === "all" ? (
                        Object.keys(stagesConfig).map((key) => (
                          <th key={key} className="border border-slate-200 p-2 text-center">
                            {stagesConfig[key].name}
                          </th>
                        ))
                      ) : (
                        <th className="border border-slate-200 p-2 text-center">
                          {stagesConfig[selectedStage]?.name}
                        </th>
                      )}
                      <th className="border border-slate-200 p-2 text-center w-12 text-red-600">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    {sortedDates.length === 0 ? (
                      <tr>
                        <td colSpan={tableMode === "all" ? 9 : 4} className="p-8 text-slate-400 font-bold italic">
                          الجدول فارغ حالياً. استخدم نموذج "إدراج وتحديث المواد" أعلاه للبدء.
                        </td>
                      </tr>
                    ) : (
                      sortedDates.map((dateStr) => {
                        const { dayName, dateDisplay } = formatArabicDate(dateStr);
                        const cellData = examData[dateStr] || {};
                        return (
                          <tr key={dateStr} className="hover:bg-slate-50 transition-colors">
                            <td className="border border-slate-200 p-2 font-bold">{dayName}</td>
                            <td className="border border-slate-200 p-2 font-mono text-slate-600">{dateDisplay}</td>
                            {tableMode === "all" ? (
                              Object.keys(stagesConfig).map((stageId) => (
                                <td key={stageId} className="border border-slate-200 p-2 font-semibold">
                                  {cellData[stageId] || "——"}
                                </td>
                              ))
                            ) : (
                              <td className="border border-slate-200 p-2 font-black text-blue-900">
                                {cellData[selectedStage] || "——"}
                              </td>
                            )}
                            <td className="border border-slate-200 p-2">
                              <button
                                onClick={() => handleDeleteRow(dateStr)}
                                className="text-red-500 hover:text-red-700 p-1"
                              >
                                <Trash2 className="w-3.5 h-3.5 mx-auto" />
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: SHEET PREVIEW & PRINT (Beautiful full density A4 formatting) */}
        {activeTab === "preview" && (
          <div className="space-y-6">
            
            {/* Action Bar */}
            <div className="no-print bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-right">
                <h4 className="text-xs font-black text-slate-800">جاهز للتصدير والطباعة 🖨️</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">تم ضبط هوامش الورق والتظليل ليتوافق مع قياسات ورق A4 القياسي.</p>
              </div>
              <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setActiveTab("control")}
                  className="flex-1 sm:flex-none px-4 py-2 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl border border-slate-300 transition duration-150 flex items-center justify-center gap-1"
                >
                  <ChevronRight className="w-4 h-4" />
                  رجوع للتعديل
                </button>
                <button
                  onClick={handleExportPDF}
                  disabled={isExportingPdf}
                  className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition duration-150 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isExportingPdf ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      جاري التحضير...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      تصدير كملف PDF 📥
                    </>
                  )}
                </button>
                <button
                  onClick={handlePrint}
                  className="flex-1 sm:flex-none px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md transition duration-150 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  طباعة وتصدير كملف PDF مباشر 🖨️
                </button>
              </div>
            </div>

            {/* THE PRINT SHEET CONTAINER */}
            <div className="flex-1 w-full flex flex-col bg-white border border-slate-300 rounded-2xl shadow-xl overflow-hidden">
              
              {/* Tool Window Bar (UI only, hidden in print) */}
              <div className="no-print bg-slate-100 px-4 py-2.5 border-b border-slate-300 flex justify-between items-center">
                <div className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-slate-500" />
                  معاينة المستند الرسمي للطباعة والتوقيع الوزاري
                </div>
                <div className="flex gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" title="إطار معاينة"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" title="إطار معاينة"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" title="إطار معاينة"></span>
                </div>
              </div>

              {/* SHEET (Acts as exact High Density print target) */}
              <div id="print-area" className="print-container p-6 sm:p-10 bg-white text-black transition-all duration-300">
                
                {/* Official Document Header */}
                <header className="flex justify-between items-start border-b-2 border-slate-900 pb-4 mb-6">
                  
                  {/* Right block: Country & Ministry info */}
                  <div className="text-right space-y-0.5">
                    <h2 className="text-[11px] font-black text-slate-900 uppercase tracking-widest leading-none">جمهورية العراق</h2>
                    <h1 className="text-sm font-black text-slate-950 leading-none">وزارة التربية والتعليم</h1>
                    <p className="text-[9px] text-slate-600 italic font-semibold leading-none pt-0.5">مكتب المدير العام / التعليم الابتدائي</p>
                  </div>
                  
                  {/* Center block: Main Exam Badge and Title */}
                  <div className="text-center px-4 flex-1">
                    <div className="inline-block px-3 py-0.5 bg-slate-950 text-white rounded-sm text-[8.5px] font-bold mb-1 uppercase tracking-tight">
                      النسخة الرسمية المعتمدة
                    </div>
                    <h2 className="text-base sm:text-lg font-black text-slate-950 tracking-tight leading-snug">
                      {dynamicTitle}
                    </h2>
                    <p className="text-[11px] font-bold text-slate-600 mt-0.5">
                      للعام الدراسي: {selectedAcademicYear || "2026 - 2027"}
                    </p>
                  </div>
                  
                  {/* Left block: School label placeholder */}
                  <div className="text-left min-w-[150px] sm:w-[180px]">
                    <div className="border-r-2 border-slate-400 pr-3 mr-auto text-right">
                      <span className="text-[9px] font-bold text-slate-400 block leading-none mb-1">المدرسة</span>
                      <span className="text-xs font-black text-slate-950 border-b border-dotted border-slate-950 pb-1 px-1 inline-block">
                        {schoolName ? schoolName : "مدرسة .................... الابتدائية"}
                      </span>
                    </div>
                  </div>

                </header>

                {/* THE TABLE (High density styling) */}
                <div className="overflow-x-auto border border-slate-950 rounded-sm">
                  <table className="w-full border-collapse text-[11.5px] sm:text-[12.5px] text-slate-950">
                    <thead>
                      <tr className="bg-slate-100 text-slate-950">
                        <th className="border border-slate-950 p-2 font-black text-center w-20 bg-slate-100">
                          اليوم
                        </th>
                        <th className="border border-slate-950 p-2 font-black text-center w-24 bg-slate-100">
                          التاريخ
                        </th>
                        
                        {tableMode === "all" ? (
                          // Display columns for all grades
                          Object.keys(stagesConfig).map((key) => (
                            <th 
                              key={key} 
                              className={`border border-slate-950 p-2 font-black text-center ${
                                key === "6" ? "bg-slate-200" : "bg-slate-100"
                              }`}
                            >
                              {stagesConfig[key].name}
                            </th>
                          ))
                        ) : (
                          // Display column for single chosen grade
                          <th className="border border-slate-950 p-2 font-black text-center bg-slate-200">
                            المادة الامتحانية لـ ({stagesConfig[selectedStage]?.name || ""})
                          </th>
                        )}

                        {/* inline action (UI only) */}
                        <th className="no-print border border-slate-950 p-2 text-center bg-slate-200 text-slate-800 w-12 font-bold text-[10px]">
                          إجراء
                        </th>
                      </tr>
                    </thead>
                    <tbody className="text-center">
                      {sortedDates.length === 0 ? (
                        <tr>
                          <td 
                            colSpan={tableMode === "all" ? 9 : 4} 
                            className="border border-slate-950 p-8 text-center text-slate-500 font-bold bg-slate-50/50"
                          >
                            <div className="flex flex-col items-center justify-center gap-1 py-4">
                              <AlertCircle className="w-6 h-6 text-slate-400" />
                              <p className="text-xs font-bold text-slate-600">لا يوجد بيانات مدرجة في هذا الجدول حالياً.</p>
                              <p className="text-[10px] text-slate-400 no-print">يرجى العودة لعلامة تبويب "لوحة التحكم" السابقة لتعبئة الجدول والبدء.</p>
                            </div>
                          </td>
                        </tr>
                      ) : (
                        sortedDates.map((dateStr) => {
                          const { dayName, dateDisplay } = formatArabicDate(dateStr);
                          const cellData = examData[dateStr] || {};
                          
                          return (
                            <tr key={dateStr} className="hover:bg-slate-50/60 transition-colors group">
                              {/* Day column */}
                              <td className="border border-slate-950 p-2 font-bold bg-slate-50">
                                {dayName}
                              </td>
                              {/* Date formatted column */}
                              <td className="border border-slate-950 p-2 font-mono text-slate-900 font-bold">
                                {dateDisplay}
                              </td>
                              
                              {tableMode === "all" ? (
                                // All grade cells
                                Object.keys(stagesConfig).map((stageId) => {
                                  const sub = cellData[stageId];
                                  const isSixth = stageId === "6";
                                  return (
                                    <td 
                                      key={stageId} 
                                      className={`border border-slate-955 p-2 relative text-center ${
                                        !sub || sub === "——" 
                                          ? "text-slate-400 font-normal italic" 
                                          : isSixth
                                            ? "font-black bg-blue-100/60 text-slate-950" 
                                            : "font-semibold bg-blue-50/30 text-slate-900"
                                      }`}
                                    >
                                      {sub || "——"}
                                      
                                      {/* Inline clear button - hidden in print */}
                                      {sub && sub !== "——" && (
                                        <button 
                                          onClick={() => handleClearCell(dateStr, stageId)}
                                          title="مسح المادة"
                                          className="no-print absolute top-0.5 left-0.5 w-3.5 h-3.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-full flex items-center justify-center text-[8px] opacity-0 group-hover:opacity-100 transition-opacity animate-none"
                                        >
                                          ×
                                        </button>
                                      )}
                                    </td>
                                  );
                                })
                              ) : (
                                // Single active grade column cell
                                <td className="border border-slate-955 p-2 font-black text-sm bg-blue-100/30 text-blue-950 relative">
                                  {cellData[selectedStage] || "——"}
                                  
                                  {/* Inline clear button */}
                                  {cellData[selectedStage] && cellData[selectedStage] !== "——" && (
                                    <button 
                                      onClick={() => handleClearCell(dateStr, selectedStage)}
                                      title="مسح المادة"
                                      className="no-print absolute top-0.5 left-0.5 w-4 h-4 bg-red-100 hover:bg-red-200 text-red-700 rounded-full flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                      ×
                                    </button>
                                  )}
                                </td>
                              )}
  
                              {/* Delete row inline action (UI only) */}
                              <td className="no-print border border-slate-955 p-2 text-center bg-slate-50">
                                <button
                                  onClick={() => handleDeleteRow(dateStr)}
                                  title="حذف هذا اليوم"
                                  className="p-0.5 text-red-500 hover:text-red-700 rounded transition"
                                >
                                  <Trash2 className="w-3.5 h-3.5 mx-auto" />
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Dynamic Bottom Info Cards */}
                <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                  
                  {/* Exam Guidelines card block */}
                  <div className="bg-slate-50 p-3 rounded border border-slate-200 text-right">
                    <h4 className="text-[10px] font-black text-slate-900 mb-1.5 border-b border-slate-200 pb-1 flex items-center gap-1">
                      <span>⚠️ تعليمات وتوجيهات امتحانية مهمة</span>
                    </h4>
                    <ul className="text-[9.5px] text-slate-700 leading-tight space-y-1 list-disc pr-3">
                      {!isMonthly && (
                        <li className="font-bold text-slate-900 list-none">
                          • يبدأ الامتحان الرسمي <span className="underline decoration-dotted text-blue-900 font-black">{examTime || "الساعة 08:00 صباحاً"}</span>.
                        </li>
                      )}
                      <li className="list-none">• إذا صادفت عطلة رسمية خلال أيام الامتحانات، فينتقل امتحان ذلك اليوم إلى اليوم الذي يليه وبنفس الترتيب.</li>
                      <li className="list-none">• جلب جميع المستلزمات الامتحانية اللازمة ولا يسمح بالاستعارة مطلقاً داخل القاعات.</li>
                      <li className="list-none">• يمنع منعاً باتاً إدخال الهواتف الذكية والساعات الإلكترونية والأجهزة اللاسلكية للقاعات.</li>
                    </ul>
                  </div>

                  {/* Signature Block */}
                  <div className="flex flex-col items-center justify-center pt-2">
                    <span className="text-xs font-black text-slate-950">مدير المدرسة</span>
                    <div className="w-36 h-6 border-b border-dotted border-slate-950 mt-2 text-center text-[11.5px] font-black text-slate-900">
                      {managerName ? managerName : "........................"}
                    </div>
                    <span className="text-[9px] text-slate-400 mt-1">الاسم الكامل والتوقيع الرسمي</span>
                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* CUSTOM CONFIRMATION DIALOG (Avoids blocking/hanging native confirm() within sandbox iframe) */}
      {confirmDialog && confirmDialog.isOpen && (
        <div className="no-print fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-sm w-full p-5 shadow-2xl relative text-right animate-scale-in">
            
            <button 
              onClick={() => setConfirmDialog(null)}
              className="absolute top-3 left-3 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 text-red-600 mb-3 border-b border-slate-100 pb-2">
              <AlertCircle className="w-5 h-5" />
              <h3 className="text-sm font-black text-slate-900">{confirmDialog.title}</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              {confirmDialog.message}
            </p>

            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition duration-150"
              >
                إلغاء التراجع
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow transition duration-150"
              >
                تأكيد ومتابعة
              </button>
            </div>

          </div>
        </div>
      )}

      {/* BEAUTIFUL CUSTOM TOAST SNACKBAR NOTIFICATION (Android toast notification styled) */}
      {snackbar && (
        <div className="no-print fixed bottom-16 right-4 left-4 sm:left-auto sm:max-w-xs w-full bg-slate-900/95 border border-slate-800 text-white p-3.5 rounded-xl shadow-2xl z-50 flex items-center gap-3 animate-fade-in text-right">
          <div className={`p-1.5 rounded-lg shrink-0 ${
            snackbar.type === "success" 
              ? "bg-emerald-500/20 text-emerald-400" 
              : snackbar.type === "error" 
                ? "bg-red-500/20 text-red-400" 
                : "bg-blue-500/20 text-blue-400"
          }`}>
            {snackbar.type === "success" ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : snackbar.type === "error" ? (
              <AlertCircle className="w-4 h-4" />
            ) : (
              <Info className="w-4 h-4" />
            )}
          </div>
          <p className="text-[11.5px] font-bold text-slate-100 flex-1 leading-relaxed">
            {snackbar.message}
          </p>
          <button 
            onClick={() => setSnackbar(null)} 
            className="p-1 hover:bg-white/10 rounded-full transition text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* DEVELOPER FOOTER */}
      <footer className="no-print fixed bottom-0 left-0 w-full bg-slate-900 text-slate-300 text-center py-2.5 px-4 border-t border-slate-800 shadow-xl flex flex-col xs:flex-row items-center justify-center gap-3 z-30">
        <div className="text-[11px] font-semibold flex items-center gap-1">
          <span>نظام الإدارة المدرسية الذكي v2.4.0</span>
          <span className="text-slate-500">|</span>
          <span>مطور النظام:</span>
          <strong className="text-white">علي خضر</strong>
        </div>
        <a 
          href="https://t.me/lF2003D5" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="px-2 py-0.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 hover:text-sky-300 text-[10px] font-bold rounded border border-sky-500/20 transition-all duration-150 flex items-center gap-1"
        >
          <Send className="w-2.5 h-2.5" />
          تواصل عبر تليجرام ✉️
        </a>
      </footer>

    </div>
  );
}
